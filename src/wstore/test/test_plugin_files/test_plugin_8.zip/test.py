from wstore.asset_manager.resource_plugins.plugin import Plugin

class TestPlugin(Plugin):
    def get_usage_specs(self):
        raise Exception('Call to configure expecs')

    def get_pending_accounting(self, asset, contract, order):
        pass
