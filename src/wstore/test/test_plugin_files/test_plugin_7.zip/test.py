from wstore.asset_manager.resource_plugins.plugin import Plugin

class TestPlugin(Plugin):
    def get_pending_accounting(asset, contract, order):
        pass
